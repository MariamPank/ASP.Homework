﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace _4Paws.Migrations
{
    /// <inheritdoc />
    public partial class fffff : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
