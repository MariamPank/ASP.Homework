﻿namespace _4Paws.Enums
{
    public enum Rating
    {
        VeryBad = 1,
        Bad = 2,
        Average = 3,
        Good = 4,
        Excellent = 5
    }
}
